#!/bin/bash

mkdir jobHome
mv ilcsoft_10.sh jobHome 

singularity exec -B /cvmfs --contain --home=$WORKDIR --workdir=$WORKDIR /cvmfs/cms.hep.wisc.edu/mucol/reference/mucoll_1.6_v02-07MC.sif /bin/bash ilcsoft_10.sh $*


mv jobHome/*.out .
mv jobHome/*.root .
mv jobHome/*.slcio . 
### clean dir

rm -rf jobHome


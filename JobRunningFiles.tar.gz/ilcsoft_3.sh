#!/bin/bash

source /opt/ilcsoft/muonc/init_ilcsoft.sh

git clone https://github.com/dally96/MuonCol.git

cd MuonCol

unzip NewData2.hepmc.zip

#cd MuonCutil/SoftCheck

GEO="/opt/ilcsoft/muonc/detector-simulation/geometries/MuColl_v1/MuColl_v1.xml"

ddsim --compactFile ${GEO} --inputFile NewData2.hepmc --steeringFile sim_steer_3.py &> $HOME/sim$$.out 

Marlin --InitDD4hep_mod4.DD4hepXMLFile=${GEO} reco_steer_3.xml &> $HOME/reco$$.out

Marlin LCTuple_3.xml &> $HOME/ntuple$$.out

mv histograms.root $HOME/histograms$$.root 

mv JetHistograms_3.root $HOME/JetHistograms$$.root

mv Output_REC_3.slcio $HOME/Output_REC$$.slcio

mv SimHits_3.slcio $HOME/SimHits$$.slcio 

#!/bin/bash

source /opt/ilcsoft/muonc/init_ilcsoft.sh

git clone https://github.com/dally96/MuonCol.git

cd MuonCol

unzip NewData2.hepmc.zip

#git clone https://github.com/MuonColliderSoft/MuonCutil.git

#cd MuonCutil/SoftCheck

GEO="/opt/ilcsoft/muonc/detector-simulation/geometries/MuColl_v1/MuColl_v1.xml"

ddsim --compactFile ${GEO} --inputFile NewData2.hepmc --steeringFile sim_steer_5.py &> $HOME/sim$$.out 

Marlin --InitDD4hep_mod4.DD4hepXMLFile=${GEO} reco_steer_5.xml &> $HOME/reco$$.out

Marlin LCTuple_5.xml &> $HOME/ntuple$$.out

mv histograms.root $HOME/histograms$$.root 

mv JetHistograms_5.root $HOME/JetHistograms$$.root

mv Output_REC_5.slcio $HOME/Output_REC$$.slcio

mv SimHits_5.slcio $HOME/SimHits$$.slcio 
